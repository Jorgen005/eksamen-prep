const { pool } = require('../data/db') 

const register = async (req, res) => {
    console.log("Test1")
    const { username, password, role } = req.body;
    console.log(username)


    try {
        const [results] = await pool.query('INSERT INTO users (user_name, password, role) VALUES (?, ?, ?)', [username, password, role]);

        res.status(201).json({
            id: results.insertId,
            username,
            password,
            role
        });
    }       catch (error) {
        res.status(500).json({ message: error.message});
    }
}

const login = (req, res) => {
    res.send('Login');
}

module.exports = {
    register,
    login
}
